<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

include_once('license.php' );
