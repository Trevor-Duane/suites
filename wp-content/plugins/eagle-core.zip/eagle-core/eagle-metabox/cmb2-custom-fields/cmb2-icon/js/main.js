jQuery(document).ready(function ($) {
  $('.iconselectfa').fontIconPicker({
  	theme: 'fip-grey'
  })
})
