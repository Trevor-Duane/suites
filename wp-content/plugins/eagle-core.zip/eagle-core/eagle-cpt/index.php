<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once('eagle-gallery/eagle-gallery.php' ); 
