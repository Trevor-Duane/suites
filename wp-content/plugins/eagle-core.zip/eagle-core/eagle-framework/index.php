<?php

// Include Redux Framework
include_once 'redux/framework.php';

// Include Redux Εχτενσιονσ
include_once 'redux-extension-loader.php';