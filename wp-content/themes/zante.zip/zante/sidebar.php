<div class="col-md-3">
  <div class="sidebar">
  <?php if( is_active_sidebar( 'zante_default_sidebar' ) ) : ?>
  <?php dynamic_sidebar( 'zante_default_sidebar' ) ?>
  <?php endif; ?>
  </div>
</div>
